export const NAV_LINKS = [
  { path: '/', title: 'Inicio' },
  { path: '/precios', title: 'Precios y Promos' },
  { path: '/tecnologia', title: 'Tecnología' },
  { path: '/alquiler', title: 'Alquiler' },
  { path: '/blog', title: 'Blog' },
  { path: '/contacto', title: 'Contacto' },
];

export const TESTIMONIALS = [
  {
    id: 1,
    name: 'Sofía Gonzalez',
    service: 'Combo Free',
    quote: '¡Increíble! Los resultados se notan desde la primera sesión. El lugar es súper limpio y las chicas son muy amables. Lo recomiendo 100%.',
    image: 'https://i.pravatar.cc/112?u=sofia.gonzalez',
  },
  {
    id: 2,
    name: 'Valentina Rossi',
    service: 'Axilas',
    quote: 'Me cambió la vida. Me olvidé de la cera para siempre. El tratamiento es indoloro y el ambiente muy relajante. ¡Gracias Centro de Belleza!',
    image: 'https://i.pravatar.cc/112?u=valentina.rossi',
  },
  {
    id: 3,
    name: 'Camila Fernandez',
    service: 'Rostro',
    quote: 'Tenía mis dudas pero superó todas mis expectativas. La tecnología que usan es de primera y se nota. Súper profesionales.',
    image: 'https://i.pravatar.cc/112?u=camila.fernandez',
  },
];